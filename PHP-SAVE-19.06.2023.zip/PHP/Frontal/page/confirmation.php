<?php include '../fonction.php'; head() ; pageheader_1() ?>
    <div class="container mt-5" style="padding-bottom: 150px; padding-top: 150px;">
        <div class="card">
            <div class="card-header">
                <h3>Votre message a bien été envoyé !</h3>
            </div>
            <div class="card-body" >
                <p>Merci pour votre message, nous vous répondrons dès que possible.</p>
            </div>
        </div>
    </div>
<?php pagefooter() ;?>
