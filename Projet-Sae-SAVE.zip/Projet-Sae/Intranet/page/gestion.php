<?php include '../fonction.php'; header_Intranet() ; navbar_Intranet() ?>

<div class="container m-5">
    <div class="row justify-content-center align-items-center bg-light">
        <div class="col text-center">
        <h1><a href="../page/lecture_formualire.php"><i class="fa-sharp fa-solid fa-rectangle-list fa-2xl" style="color: #000000;"></i></a></h1>
        <p>Lecture du formulaire de  la page Pompier volontaire</p>
        </div>
        <div class="col text-center">
            <h1><a href="../page/modif_formualaire.php"><i class="fa-solid fa-newspaper fa-2xl" style="color: #000000;"></i></a></h1>
            <p>Modification des actulaitées</p>
        </div>
    </div>
</div>




<?php pagefooter_Intranet() ;?>