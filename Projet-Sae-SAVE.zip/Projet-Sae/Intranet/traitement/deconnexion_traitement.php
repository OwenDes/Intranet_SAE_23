<?php
session_start();
$_SESSION = array();
session_destroy();
session_write_close();
header("Location: http://php/Sa%c3%a9%2024/Projet-Sae//Frontal/page/page0.php");
exit();
?>